﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace P0030481923019
{
    public partial class frmHome : Form
    {
        public frmHome()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            double[,] Matriz = new double[9, 4];
            string valor;
            bool checaCancel;
            double totalMes, totalGeral = 0;

            lstbSaida.Items.Clear();
            for (var mes = 0; mes < 9; mes++)
            {
                checaCancel = false;
                totalMes = 0;
                for (var sem = 0; sem < 4; sem++)
                {
                    valor = Interaction.InputBox("Total do mês " + (mes + 1) +
                        " - Semana " + (sem + 1), "Entrada de Dados");
                    if (valor == "")
                    {
                        checaCancel = true;
                        break;
                    }
                    if (double.TryParse(valor, out Matriz[mes, sem]))
                    {
                        totalMes += Matriz[mes, sem];
                        lstbSaida.Items.Add("Total do mês " + (mes + 1) +
                            " - Semana " + (sem + 1) + ": R$" + Matriz[mes, sem].ToString("N2"));
                    }
                    else
                    {
                        MessageBox.Show("Dados inválidos!");
                        sem--;
                    }
                }
                if (checaCancel) break;
                else
                {
                    lstbSaida.Items.Add(">> Total do mês: R$" + totalMes.ToString("N2"));
                    lstbSaida.Items.Add("---------------------------------");
                    totalGeral += totalMes;
                }
            }
            lstbSaida.Items.Add(">> Total geral: R$" + totalGeral.ToString("N2"));
        }
    }
}
