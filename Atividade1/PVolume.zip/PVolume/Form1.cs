﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PVolume
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double raio, altura, volume;

            if ((double.TryParse(textBox1.Text, out raio) &&
                double.TryParse(textBox2.Text, out altura)))
            {
                volume = Math.PI * Math.Pow(raio, 2) * altura;
                textBox3.Text = volume.ToString("N2");
            }
            else
                MessageBox.Show("Dados inválidos!");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
        }
    }
}
