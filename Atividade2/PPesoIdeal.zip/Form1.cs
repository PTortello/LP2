﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PPesoIdeal
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalc_Click(object sender, EventArgs e)
        {
            double altura, pesoAtual, pesoIdeal;
            string estado;

            if ((double.TryParse(txtAltura.Text, out altura) &&
                double.TryParse(txtPeso.Text, out pesoAtual)))
            {
                if (rbtnMasc.Checked == true)
                {
                    pesoIdeal = Math.Round(72.7*altura-58, 2);
                }
                else
                    pesoIdeal = Math.Round(62.1*altura-44.7, 2);
                if (pesoAtual > pesoIdeal)
                {
                    estado = "acima do";
                }
                else if (pesoAtual < pesoIdeal)
                {
                    estado = "abaixo do";
                }
                else
                {
                    estado = "no";
                }
                MessageBox.Show("Seu peso atual é " + pesoAtual.ToString("N2") + " kg.\n"
                    + "Seu peso ideal é " + pesoIdeal + " kg.\n"
                    + "Você está " + estado + " seu peso ideal.", "Peso Ideal",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
                MessageBox.Show("Dados inválidos!", "Peso Ideal",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.ActiveControl = txtAltura;
        }
    }
}
