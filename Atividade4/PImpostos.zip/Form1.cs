﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PImpostos
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            double descINSS, descIRPF, salFamilia=0, salLiquido;
            string sexo = "do sr.", estadoCivil = "solteir";
            char x = 'o';

            if (double.TryParse(mskbxSalBruto.Text, out double salBruto) &&
                int.TryParse(mskbxNumFilhos.Text, out int numFilhos))
            {
                // Desconto INSS
                if (salBruto <= 800.47)
                {
                    mskbxAliqINSS.Text = "7,65%";
                    descINSS =  7.65 / 100 * salBruto;
                }
                else if (salBruto <= 1050)
                {
                    mskbxAliqINSS.Text = "8,65%";
                    descINSS = 8.65 / 100 * salBruto;
                }
                else if (salBruto <= 1400.77)
                {
                    mskbxAliqINSS.Text = "9,00%";
                    descINSS = 9.00 / 100 * salBruto;
                }
                else if (salBruto <= 2801.56)
                {
                    mskbxAliqINSS.Text = "11,00%";
                    descINSS = 11.00 / 100 * salBruto;
                }
                else
                {
                    mskbxAliqINSS.Text = "Teto";
                    descINSS = 308.17;
                }

                // Desconto IRPF
                if (salBruto > 1257.12)
                {
                    if (salBruto <= 2512.08)
                    {
                        mskbxAliqIRPF.Text = "15,00%";
                        descIRPF = 15.0 / 100 * salBruto;
                    }
                    else
                    {
                        mskbxAliqIRPF.Text = "27,50%";
                        descIRPF = 27.5 / 100 * salBruto;
                    }
                }
                else
                {
                    mskbxAliqIRPF.Text = "0,00%";
                    descIRPF = 0;
                }

                // Salário família
                if (salBruto <= 435.52)
                {
                    salFamilia = numFilhos * 22.33;
                }
                else if (salBruto <= 654.61)
                {
                    salFamilia = numFilhos * 15.74;
                }

                salLiquido = salBruto + salFamilia - descINSS - descIRPF;

                mskbxSalFamilia.Text = salFamilia.ToString("F");
                mskbxDescINSS.Text = descINSS.ToString("F");
                mskbxDescIRPF.Text = descIRPF.ToString("F");
                mskbxSalLiquido.Text = salLiquido.ToString("F");

                if (rbtnF.Checked)
                {
                    sexo = "da sra.";
                    x = 'a';
                }

                if (ckbxCasado.Checked)
                {
                    estadoCivil = "casad";
                }

                lblDados.Text = "Os descontos do salário " +
                    sexo + " " + mskbxNome.Text + " que é " +
                    estadoCivil + x + " e que tem " + numFilhos + " filho(s) são:";
            }
            else MessageBox.Show("Valores inválidos!", "Impostos",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }
}
