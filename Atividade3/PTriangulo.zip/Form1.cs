﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTriangulo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            txtLadoA.Focus();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            if (long.TryParse(txtLadoA.Text, out long ladoA) &&
                long.TryParse(txtLadoB.Text, out long ladoB) &&
                long.TryParse(txtLadoC.Text, out long ladoC))
            {
                if ((Math.Abs(ladoB - ladoC) < ladoA && ladoA < ladoB + ladoC) &&
                    (Math.Abs(ladoA - ladoC) < ladoB && ladoB < ladoA + ladoC) &&
                    (Math.Abs(ladoA - ladoB) < ladoC && ladoC < ladoA + ladoB))
                {
                    if (ladoA == ladoB)
                    {
                        if (ladoA == ladoC)
                        {
                            lblResultado.Text = "Equilátero";
                        }
                        else
                        {
                            lblResultado.Text = "Isósceles";
                        }
                    }
                    else
                    {
                        if (ladoA == ladoC)
                        {
                            lblResultado.Text = "Isósceles";
                        }
                        else
                        {
                            if (ladoB == ladoC)
                            {
                                lblResultado.Text = "Isósceles";
                            }
                            else
                            {
                                lblResultado.Text = "Escaleno";
                            }
                        }
                    }
                }
                else
                {
                    lblResultado.Text = "Não forma triângulo.";
                }
            }
            else MessageBox.Show("Valores inválidos!\n" +
                "Digite valores inteiros positivos.",
                "Triangulo", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }
}
