﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;
using Microsoft.VisualBasic; // adicionado, ver linha 30

namespace PAtividade7
{
    public partial class frmHome : Form
    {
        public frmHome()
        {
            InitializeComponent();
        }

        private void btnEx1_Click(object sender, EventArgs e)
        {
            int[] Vetor = new int[20];
            string auxiliar = "";
            string valor = "";

            for (var x = 0; x < 20; x++)
            {
                // menu Project > Add Reference > Framework > Microsoft.VisualBasic
                // adicionar linha do comentário "adicionado", linha 10 deste código
                valor = Interaction.InputBox("Digite um valor na posição:"+(x+1),
                    "Entrada de Dados");
                if (valor == "")
                {
                    break;
                }
                if (Int32.TryParse(valor, out Vetor[x]))
                {
                    //auxiliar = auxiliar + "\n" + Vetor[x].ToString();
                    auxiliar = Vetor[x].ToString() + "\n" + auxiliar;
                }
                else
                {
                    MessageBox.Show("Número inválido!");
                    x--;
                }
            }
            MessageBox.Show(auxiliar);
        }

        private void btnEx2_Click(object sender, EventArgs e)
        {
            int[] Vetor = new int[20];
            string auxiliar = "";
            string valor = "";

            for (var x = 0; x < 20; x++)
            {
                valor = Interaction.InputBox("Entre com dado na posição: " + (x + 1),
                    "Entrada de Dados");
                if (valor == "")
                {
                    break;
                }
                if (!int.TryParse(valor, out Vetor[x]))
                {
                    MessageBox.Show("Número inválido!");
                    x--;
                }
            }

            Array.Reverse(Vetor);
            for (var x = 0; x < 0; x++)
            {
                auxiliar = auxiliar + "\n" + Vetor[x];
            }

            // comentado abaixo faz o mesmo que linhas 75 a 79, sem usar o método Reverse()
            /*
            for (var x = 19; x >= 0; x--)
            {
                auxiliar = auxiliar + "\n" + Vetor[x].ToString();
            }
            MessageBox.Show(auxiliar);
            */
        }

        private void btnEx3_Click(object sender, EventArgs e)
        {
            double[] Quantidades = new double[10];
            double[] Precos = new double[10];
            double faturamento=0;
            string valor = "";

            for (var x = 0; x < 10; x++)
            {
                valor = Interaction.InputBox("Entre com a quantidade da posição "
                    + (x + 1), "Entrada de Dados");
                if (valor == "")
                {
                    break;
                }
                if (!double.TryParse(valor, out Quantidades[x]))
                {
                    MessageBox.Show("Valor inválido!");
                    x--;
                }
                else
                {
                    do
                    {
                        valor = Interaction.InputBox("Entre com o preço da posição "
                            + (x + 1), "Entrada de Dados");
                    } while (!double.TryParse(valor, out Precos[x]));
                    faturamento += Quantidades[x] * Precos[x];
                }
            }
            MessageBox.Show("Faturamento: " + faturamento.ToString("N2"));
        }

        private void btnEx4_Click(object sender, EventArgs e)
        {
            string[] Alunos = {"Viviane", "André", "Hélio", "Denise", "Junior",
                "Leonardo", "Jose", "Nelma", "Tobby"};
            Int32 I, Total = 0;
            Int32 N = Alunos.Length;

            for (I=0; I<N-1; I++)
            {
                Total += Alunos[I].Length;
            }
            MessageBox.Show("Total de caracteres: " + Total);
        }

        private void btnEx5_Click(object sender, EventArgs e)
        {
            ArrayList Alunos = new ArrayList(new string[] {
                "Ana", "André", "Débora", "Fátima", "João", "Janete",
                "Otávio", "Marcelo", "Pedro", "Thais"});
            Alunos.Remove("Otávio");

            string lista="";
            foreach (string nome in Alunos)
            {
                lista = lista + nome + "\n";
            }
            MessageBox.Show(lista);
            // faz o mesmo que as linhas 145 a 150 acima:
            // MessageBox.Show(string.Join(Environment.NewLine, Alunos.OfType<Object>()));
        }

        private void btnEx6_Click(object sender, EventArgs e)
        {
            double[,] notas = new double[21, 4];
            double media;
            string valor = "";
            string lista = "";

            for (var i=1; i<21; i++)
            {
                media = 0;
                for (var j=1; j<4; j++)
                {
                    valor = Interaction.InputBox("Nota " + j + " do aluno " + i + ": ",
                        "Entrada de Notas");
                    if (valor == "")
                    {
                        break;
                    }
                    if (!double.TryParse(valor, out notas[i, j]))
                    {
                        MessageBox.Show("Valor inválido!");
                        j--;
                    }
                    else
                    {
                        media += notas[i, j];
                    }
                }
                media /= 3;
                lista += "Aluno " + i.ToString() + ": média: " + media.ToString("N2") + "\n";
            }
            MessageBox.Show(lista);
        }

        private void btnEx7_Click(object sender, EventArgs e)
        {
            Form frm = Application.OpenForms["Form2"];
            if (frm != null)
            {
                frm.Close();
            }
            frmEx7 frm2 = new frmEx7();
            frm2.Show();
        }
    }
}
