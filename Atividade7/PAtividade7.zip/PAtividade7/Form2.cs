﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PAtividade7
{
    public partial class frmEx7 : Form
    {
        public frmEx7()
        {
            InitializeComponent();
        }

        private void btnExec_Click(object sender, EventArgs e)
        {
            string[] VetorNome = new string[9];
            int[] VetorNumCaract = new int[9];
            string valor = "";

            lstbxSaida.Items.Clear();

            for (var i = 0; i < 9; i++)
            {
                valor = Interaction.InputBox("Digite o nome " + (i+1), "Entrada de Dados");
                if (valor == "")
                {
                    break;
                }
                VetorNome[i] = valor;
                VetorNumCaract[i] = valor.Length - valor.Count(Char.IsWhiteSpace);
            }

            for (var i = 0; i < 9; i++)
            {
                lstbxSaida.Items.Add("o nome: " + VetorNome[i] + " tem " + VetorNumCaract[i] + " caracteres\n");
            }
        }
    }
}
